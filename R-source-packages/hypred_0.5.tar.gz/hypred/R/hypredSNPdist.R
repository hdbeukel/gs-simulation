setGeneric("hypredSNPdist",
           def = function(object,
             ...)
           {
             standardGeneric("hypredSNPdist")
           }
           )
