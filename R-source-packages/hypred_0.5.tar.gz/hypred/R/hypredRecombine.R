setGeneric("hypredRecombine",
           def = function(object,
             ...)
           {
             standardGeneric("hypredRecombine")
           }
           )
