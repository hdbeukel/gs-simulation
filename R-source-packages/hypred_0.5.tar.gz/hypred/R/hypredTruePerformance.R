setGeneric("hypredTruePerformance",
           def = function(object,
             ...)
           {
             standardGeneric("hypredTruePerformance")
           }
           )

