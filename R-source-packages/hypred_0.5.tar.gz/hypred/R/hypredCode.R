setGeneric("hypredCode",
           def = function(object,
             ...)
           {
             standardGeneric("hypredCode")
           }
           )
