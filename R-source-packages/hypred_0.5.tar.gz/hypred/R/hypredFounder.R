setGeneric("hypredFounder",
           def = function(object,
             ...)
           {
             standardGeneric("hypredFounder")
           }
           )
