setGeneric("hypredNewQTL",
           def = function(object,
             ...)
           {
             standardGeneric("hypredNewQTL")
           }
           )
