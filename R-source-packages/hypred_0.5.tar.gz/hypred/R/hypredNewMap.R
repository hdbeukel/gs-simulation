setGeneric("hypredNewMap",
           def = function(object,
             ...)
           {
             standardGeneric("hypredNewMap")
           }
           )

