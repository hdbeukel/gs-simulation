setGeneric("hypredTpGenomeSpecific",
           def = function(object,
             ...)
           {
             standardGeneric("hypredTpGenomeSpecific")
           }
           )

